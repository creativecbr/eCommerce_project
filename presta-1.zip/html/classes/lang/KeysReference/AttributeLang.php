<?php
/**
 * 2007-2019 PrestaShop and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2019 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */
trans('S', 'Shop.Demo.Catalog');
trans('M', 'Shop.Demo.Catalog');
trans('L', 'Shop.Demo.Catalog');
trans('One size', 'Shop.Demo.Catalog');
trans('Grey', 'Shop.Demo.Catalog');
trans('Taupe', 'Shop.Demo.Catalog');
trans('Beige', 'Shop.Demo.Catalog');
trans('White', 'Shop.Demo.Catalog');
trans('Off White', 'Shop.Demo.Catalog');
trans('Red', 'Shop.Demo.Catalog');
trans('Black', 'Shop.Demo.Catalog');
trans('Camel', 'Shop.Demo.Catalog');
trans('Orange', 'Shop.Demo.Catalog');
trans('Blue', 'Shop.Demo.Catalog');
trans('Green', 'Shop.Demo.Catalog');
trans('Yellow', 'Shop.Demo.Catalog');
trans('Brown', 'Shop.Demo.Catalog');
trans('35', 'Shop.Demo.Catalog');
trans('36', 'Shop.Demo.Catalog');
trans('37', 'Shop.Demo.Catalog');
trans('38', 'Shop.Demo.Catalog');
trans('39', 'Shop.Demo.Catalog');
trans('40', 'Shop.Demo.Catalog');
trans('Pink', 'Shop.Demo.Catalog');
