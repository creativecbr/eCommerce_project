package consts;

public interface Consts {

    public static final String SITE = "http://3.209.82.53/";

    public static final Integer AMOUNT_OF_PRODUCTS = 10;

    public static final String PAGE_PARAM = "?page=";

    public static final Integer AMOUNT_OF_CATEGORIES = 2;

    public static final Integer QUANTITY_OF_REMOVING_PRODUCTS = 1;

    public static final Integer QUANTITY_OF_BUYING_PRODUCTS = 5;


}
